#!/usr/bin/env python3
"""
NMS API Console — a tiny local web UI + proxy for the Nomad NMS REST API.

Why this exists: the NMS server does not send CORS headers, so a browser page
(including Swagger "Try it out") cannot call it directly. This script runs a
small local HTTP server that:
  - serves a single-page web UI on http://localhost:8787
  - proxies API calls server-side (Python -> NMS), so the browser never makes a
    cross-origin request and CORS never applies.

Usage:
    python nms_console.py
    # then open http://localhost:8787 in your browser

No external dependencies — standard library only (works with the system python3).
Auth: log in once in the UI with your own NMS username/password. The token is
held in memory in this local process only (never written to disk, never logged).
"""

import json
import os
import ssl
import sys
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, urlencode

NMS_BASE = "https://nms-obb.nomadrail.com/nms/rest"
LISTEN_PORT = 8787

# Endpoint catalog generated from the swagger spec (scripts/nms_endpoints.json).
# Regenerate with the one-liner in this file's header if the spec changes.
_here = os.path.dirname(os.path.abspath(__file__))
try:
    with open(os.path.join(_here, "nms_endpoints.json"), encoding="utf-8") as _f:
        ENDPOINTS = json.load(_f)
except FileNotFoundError:
    ENDPOINTS = []

# In-memory token store for this local process (not persisted).
STATE = {"token": None, "username": None}

# NMS presents a cert we reach over the open internet; verify=off mirrors the
# `curl -k` the team already uses. Traffic is still TLS-encrypted in transit.
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE


def nms_request(method, path, query=None, body=None, token=None, timeout=30):
    """Make a server-side request to NMS. Returns (status, body_bytes, content_type)."""
    url = NMS_BASE + path
    if query:
        url += "?" + urlencode(query)
    headers = {"content-type": "application/json;charset=UTF-8",
               "accept": "application/json"}
    if token:
        headers["Auth-Token"] = token
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, context=SSL_CTX, timeout=timeout) as resp:
            return resp.status, resp.read(), resp.headers.get("content-type", "")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("content-type", "")
    except Exception as e:
        return 599, json.dumps({"proxyError": str(e)}).encode(), "application/json"


INDEX_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>NMS API Console</title>
<style>
  :root {
    --bg:#0f1720; --panel:#17212b; --edge:#26323f; --ink:#e7edf3;
    --muted:#8fa2b5; --accent:#4f9cf9; --ok:#3fb950; --err:#f85149; --field:#0d141b;
  }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--ink);
         font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif; }
  header { padding:14px 20px; border-bottom:1px solid var(--edge);
           display:flex; align-items:center; gap:14px; }
  header h1 { font-size:16px; margin:0; font-weight:600; }
  #authstate { margin-left:auto; font-size:12px; color:var(--muted); }
  #authstate.ok { color:var(--ok); }
  .wrap { max-width:1100px; margin:0 auto; padding:20px; }
  .panel { background:var(--panel); border:1px solid var(--edge); border-radius:10px;
           padding:16px 18px; margin-bottom:16px; }
  .panel h2 { font-size:13px; text-transform:uppercase; letter-spacing:.06em;
              color:var(--muted); margin:0 0 12px; }
  label { display:block; font-size:12px; color:var(--muted); margin:8px 0 3px; }
  input, select, textarea {
    width:100%; background:var(--field); color:var(--ink); border:1px solid var(--edge);
    border-radius:7px; padding:8px 10px; font:inherit; }
  input:focus, select:focus { outline:1px solid var(--accent); border-color:var(--accent); }
  input[type=date] { color-scheme:dark; }              /* dark calendar popup + visible icon */
  input[type=date]::-webkit-calendar-picker-indicator { filter:invert(0.8); cursor:pointer; }
  .row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .row3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; }
  button { background:var(--accent); color:#07121f; border:0; border-radius:7px;
           padding:9px 16px; font:600 14px/1 inherit; cursor:pointer; margin-top:12px; }
  button.secondary { background:transparent; color:var(--accent);
                     border:1px solid var(--accent); }
  button:disabled { opacity:.5; cursor:default; }
  .hint { font-size:11px; color:var(--muted); margin-top:4px; }
  pre { background:var(--field); border:1px solid var(--edge); border-radius:8px;
        padding:12px; overflow:auto; max-height:60vh; font:12px/1.5 ui-monospace,Consolas,monospace;
        white-space:pre-wrap; word-break:break-word; }
  .status { font-size:12px; margin:8px 0; }
  .status.ok { color:var(--ok); } .status.err { color:var(--err); }
  datalist { color:#000; }
  .inline { display:flex; gap:10px; align-items:end; }
  .inline > div { flex:1; }
  .viewtab { background:var(--field); color:var(--muted); border:0; border-radius:0;
             padding:7px 14px; font:600 12px/1 inherit; cursor:pointer; }
  .viewtab.active { background:var(--accent); color:#07121f; }
  table { border-collapse:collapse; width:100%; font:12px/1.4 ui-monospace,Consolas,monospace; }
  th, td { border:1px solid var(--edge); padding:5px 8px; text-align:left; white-space:nowrap;
           max-width:340px; overflow:hidden; text-overflow:ellipsis; }
  th { position:sticky; top:0; background:var(--panel); color:var(--muted);
       cursor:pointer; user-select:none; }
  th:hover { color:var(--ink); }
  tbody tr:nth-child(even) { background:rgba(255,255,255,.02); }
  td.num { text-align:right; }
</style>
</head>
<body>
<header>
  <h1>NMS API Console</h1>
  <span id="authstate">not logged in</span>
</header>

<div class="wrap">

  <div class="panel" id="loginpanel">
    <h2>1 · Authenticate</h2>
    <div class="row">
      <div>
        <label>Username</label>
        <input id="u" autocomplete="username" placeholder="your.nms.login"/>
      </div>
      <div>
        <label>Password</label>
        <input id="p" type="password" autocomplete="current-password"/>
      </div>
    </div>
    <div class="hint">Use your own NMS login. Token is held only in this local process's memory — never written to disk.</div>
    <button id="loginbtn">Log in</button>
    <div class="status" id="loginstatus"></div>
  </div>

  <div class="panel">
    <h2>2 · Pick a train</h2>
    <button id="loadtrains" class="secondary">Load train list (project 50)</button>
    <div class="inline" style="margin-top:12px">
      <div>
        <label>Train (name or official id) — type to filter</label>
        <input id="trainpick" list="trainlist" placeholder="T4736109"/>
        <datalist id="trainlist"></datalist>
      </div>
      <div style="flex:0 0 160px">
        <label>Resolved relativeId</label>
        <input id="resolvedid" readonly placeholder="—"/>
      </div>
    </div>
    <div class="hint">The API needs the numeric <b>relativeId</b>, not the T-name. This resolves it for you.</div>
  </div>

  <div class="panel">
    <h2>3 · Query</h2>
    <label>Filter endpoints</label>
    <input id="epfilter" placeholder="type to filter, e.g. sim, mar3, alarm, position"/>
    <label style="margin-top:8px">Endpoint (<span id="epcount">0</span> available)</label>
    <select id="endpoint" size="1"></select>
    <div class="hint" id="epsummary"></div>

    <div id="params"></div>
    <div class="hint">Dates are sent as full timestamps with +02:00 (CEST). trainId auto-resolves from the train picker above.</div>
    <button id="runbtn">Run query</button>
    <div class="status" id="runstatus"></div>
  </div>

  <div class="panel">
    <h2>Response</h2>
    <div id="resptools" style="display:none; align-items:center; gap:12px; margin-bottom:10px; flex-wrap:wrap">
      <div style="display:flex; gap:0; border:1px solid var(--edge); border-radius:7px; overflow:hidden">
        <button id="viewTable" class="viewtab active" style="margin:0">Table</button>
        <button id="viewJson"  class="viewtab" style="margin:0">JSON</button>
      </div>
      <span id="rowcount" class="hint" style="margin:0"></span>
      <button id="csvbtn" class="secondary" style="margin:0 0 0 auto">Download CSV</button>
    </div>
    <div id="tablewrap" style="overflow:auto; max-height:60vh; display:none">
      <table id="resptable"></table>
    </div>
    <pre id="out">—</pre>
  </div>

</div>

<script>
let TRAINS = [];

// Default date range: from = yesterday, to = today (local date, YYYY-MM-DD).
const _fmtD = d => d.toISOString().slice(0,10);
const DATE_TODAY = _fmtD(new Date());
const DATE_YEST  = _fmtD(new Date(Date.now() - 86400000));

function setAuthState(name){
  const el = document.getElementById('authstate');
  if(name){ el.textContent = 'logged in as ' + name; el.className='ok'; }
  else { el.textContent = 'not logged in'; el.className=''; }
}

async function api(path, opts){
  const r = await fetch(path, opts);
  const txt = await r.text();
  let body; try { body = JSON.parse(txt); } catch { body = txt; }
  return { status:r.status, body };
}

document.getElementById('loginbtn').onclick = async () => {
  const u = document.getElementById('u').value.trim();
  const p = document.getElementById('p').value;
  const s = document.getElementById('loginstatus');
  s.textContent = 'authenticating…'; s.className='status';
  const r = await api('/_login', {method:'POST', headers:{'content-type':'application/json'},
                       body: JSON.stringify({username:u, password:p})});
  if(r.status===200 && r.body.ok){
    s.textContent = 'authenticated ✓'; s.className='status ok';
    setAuthState(r.body.username);
    document.getElementById('p').value='';
  } else {
    s.textContent = 'login failed: ' + (r.body.error || r.status); s.className='status err';
  }
};

document.getElementById('loadtrains').onclick = async () => {
  const r = await api('/_trains');
  if(r.status!==200){ document.getElementById('out').textContent = JSON.stringify(r.body,null,2); return; }
  TRAINS = r.body;
  const dl = document.getElementById('trainlist');
  dl.innerHTML='';
  TRAINS.sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  for(const t of TRAINS){
    const o=document.createElement('option');
    o.value = t.name;
    o.label = t.name + '  ·  ' + t.type + '  ·  id ' + t.relativeId;
    dl.appendChild(o);
  }
  document.getElementById('runstatus').textContent = 'Loaded ' + TRAINS.length + ' trains.';
};

function resolve(){
  let v = document.getElementById('trainpick').value.trim();
  const norm = s => String(s).replace(/^T/i,'').replace(/[-\s]/g,'');  // T4736-109 -> 4736109
  const nv = norm(v);
  const t = TRAINS.find(x =>
        x.name===v
     || String(x.officialId)===v
     || String(x.relativeId)===v
     || norm(x.name)===nv          // painted number w/o the T, e.g. 4736109
  );
  document.getElementById('resolvedid').value = t ? t.relativeId : '';
  return t ? t.relativeId : '';
}
document.getElementById('trainpick').addEventListener('input', resolve);

// ---- Endpoint catalog (all GET endpoints from the swagger spec) ----
let ENDPOINTS = [];
const TRAIN_PARAMS = new Set(['trainId','relativeId']);      // resolved from the train picker
const DATE_PARAMS  = new Set(['from','to','date']);          // rendered as calendars

function isoCEST(d, endOfDay){
  if(!d) return '';
  return d + (endOfDay ? 'T23:59:59+02:00' : 'T00:00:00+02:00');
}

async function loadEndpoints(){
  const r = await api('/_endpoints');
  ENDPOINTS = r.body || [];
  renderEndpointList('');
}

function renderEndpointList(filter){
  const sel = document.getElementById('endpoint');
  const f = (filter||'').toLowerCase();
  const shown = ENDPOINTS.filter(e =>
     !f || e.path.toLowerCase().includes(f) || e.tag.toLowerCase().includes(f)
        || (e.summary||'').toLowerCase().includes(f));
  sel.innerHTML='';
  let curTag=null, grp=null;
  for(const e of shown){
    if(e.tag!==curTag){ curTag=e.tag; grp=document.createElement('optgroup'); grp.label=e.tag; sel.appendChild(grp); }
    const o=document.createElement('option');
    o.value = e.path;
    o.textContent = e.path + (e.summary ? '  —  '+e.summary : '');
    grp.appendChild(o);
  }
  document.getElementById('epcount').textContent = shown.length;
  if(shown.length){ sel.value = shown[0].path; renderParams(); }
  else { document.getElementById('params').innerHTML=''; document.getElementById('epsummary').textContent='no match'; }
}

function currentEndpoint(){
  const p = document.getElementById('endpoint').value;
  return ENDPOINTS.find(e => e.path===p);
}

function renderParams(){
  const e = currentEndpoint();
  const box = document.getElementById('params');
  document.getElementById('epsummary').textContent = e ? (e.tag + ' · ' + (e.summary||'(no summary)')) : '';
  if(!e){ box.innerHTML=''; return; }
  let h = '<div class="row3">';
  let n=0;
  for(const p of e.params){
    n++;
    const isDate = DATE_PARAMS.has(p.name) || p.fmt==='date-time';
    const isTrain = TRAIN_PARAMS.has(p.name);
    const req = p.req ? ' *' : '';
    const loc = p.in==='path' ? ' (path)' : '';
    const def = p.name==='projectId' ? ' value="50"' : (p.name==='token' ? '' : '');
    if(isDate){
      const dflt = p.name==='to' ? DATE_TODAY : (p.name==='from' ? DATE_YEST : '');
      h += '<div><label>'+p.name+req+loc+'</label><input type="date" data-pname="'+p.name+'" value="'+dflt+'"/></div>';
    } else if(isTrain){
      h += '<div><label>'+p.name+req+loc+' (auto from picker)</label><input data-pname="'+p.name+'" data-train="1" placeholder="uses resolved train" readonly value=""/></div>';
    } else {
      h += '<div><label>'+p.name+req+loc+'</label><input data-pname="'+p.name+'"'+def+'/></div>';
    }
    if(n%3===0) h += '</div><div class="row3">';
  }
  h += '</div>';
  box.innerHTML = h;
}

document.getElementById('epfilter').addEventListener('input', e => renderEndpointList(e.target.value));
document.getElementById('endpoint').addEventListener('change', renderParams);

document.getElementById('runbtn').onclick = async () => {
  const e = currentEndpoint();
  const s = document.getElementById('runstatus');
  if(!e){ s.textContent='Pick an endpoint.'; s.className='status err'; return; }
  s.textContent = 'querying…'; s.className='status';

  let path = e.path;
  const q = new URLSearchParams();
  const trainId = resolve();   // '' if none picked

  for(const p of e.params){
    let val;
    if(TRAIN_PARAMS.has(p.name)){
      val = trainId;
      if(!val && p.req){ s.textContent='This endpoint needs a train — pick one above (and click "Load train list").'; s.className='status err'; return; }
    } else {
      const el = document.querySelector('[data-pname="'+p.name+'"]');
      val = el ? el.value.trim() : '';
      if((DATE_PARAMS.has(p.name)||p.fmt==='date-time') && val){
        val = isoCEST(val, p.name==='to');
      }
    }
    if(val==='' && !p.req) continue;         // skip empty optional params
    if(p.in==='path'){
      path = path.replace('{'+p.name+'}', encodeURIComponent(val));
    } else {
      q.set(p.name, val);
    }
  }
  const qs = q.toString();
  const full = path + (qs ? '?'+qs : '');
  const r = await api('/_proxy?path=' + encodeURIComponent(full));
  s.textContent = 'HTTP ' + r.status + '  ·  ' + full; s.className = (r.status>=200&&r.status<300)?'status ok':'status err';
  renderResponse(r.body);
};

// ---- Response rendering: table (default for arrays) + JSON + CSV ----
let LAST_ROWS = [];      // flattened rows for the current response
let LAST_COLS = [];      // column order
let SORT = {col:null, dir:1};

function flatten(obj, prefix, out){
  out = out || {}; prefix = prefix || '';
  if(obj===null || typeof obj!=='object'){ out[prefix||'value'] = obj; return out; }
  for(const k of Object.keys(obj)){
    const v = obj[k]; const key = prefix ? prefix+'.'+k : k;
    if(v!==null && typeof v==='object' && !Array.isArray(v)) flatten(v, key, out);
    else out[key] = Array.isArray(v) ? JSON.stringify(v) : v;
  }
  return out;
}

function renderResponse(body){
  const out = document.getElementById('out');
  const tools = document.getElementById('resptools');
  const arr = Array.isArray(body) ? body
            : (body && Array.isArray(body.content) ? body.content : null);   // some endpoints wrap in .content
  if(arr && arr.length && typeof arr[0]==='object'){
    LAST_ROWS = arr.map(x => flatten(x));
    const cols = [];
    for(const row of LAST_ROWS) for(const k of Object.keys(row)) if(!cols.includes(k)) cols.push(k);
    LAST_COLS = cols;
    SORT = {col:null, dir:1};
    document.getElementById('rowcount').textContent = arr.length + ' rows · ' + cols.length + ' columns';
    tools.style.display = 'flex';
    showTable();
  } else {
    // Not a tabular array — JSON only.
    LAST_ROWS = []; LAST_COLS = [];
    tools.style.display = 'none';
    document.getElementById('tablewrap').style.display = 'none';
    out.style.display = 'block';
    out.textContent = typeof body==='string' ? body : JSON.stringify(body, null, 2);
  }
}

function fmtCell(v){
  if(v===null || v===undefined) return '';
  // Heuristic: unix-ms timestamps -> readable ISO (helps the 'timestamp' field)
  if(typeof v==='number' && v>1e12 && v<2e12) return new Date(v).toISOString().replace('T',' ').slice(0,19);
  return String(v);
}

function showTable(){
  const rows = LAST_ROWS.slice();
  if(SORT.col!==null){
    rows.sort((a,b)=>{
      const x=a[SORT.col], y=b[SORT.col];
      if(x===y) return 0;
      if(x===null||x===undefined) return 1;
      if(y===null||y===undefined) return -1;
      return (x>y?1:-1)*SORT.dir;
    });
  }
  let h = '<thead><tr>';
  for(const c of LAST_COLS){
    const arrow = SORT.col===c ? (SORT.dir>0?' ▲':' ▼') : '';
    h += '<th data-c="'+c.replace(/"/g,'&quot;')+'">'+c+arrow+'</th>';
  }
  h += '</tr></thead><tbody>';
  for(const row of rows){
    h += '<tr>';
    for(const c of LAST_COLS){
      const v = row[c];
      const cls = (typeof v==='number') ? ' class="num"' : '';
      const disp = fmtCell(v).replace(/</g,'&lt;');
      h += '<td'+cls+' title="'+disp.replace(/"/g,'&quot;')+'">'+disp+'</td>';
    }
    h += '</tr>';
  }
  h += '</tbody>';
  const t = document.getElementById('resptable');
  t.innerHTML = h;
  t.querySelectorAll('th').forEach(th => th.onclick = ()=>{
    const c = th.getAttribute('data-c');
    if(SORT.col===c) SORT.dir *= -1; else { SORT.col=c; SORT.dir=1; }
    showTable();
  });
  document.getElementById('tablewrap').style.display = 'block';
  document.getElementById('out').style.display = 'none';
  document.getElementById('viewTable').classList.add('active');
  document.getElementById('viewJson').classList.remove('active');
}

function showJson(){
  document.getElementById('tablewrap').style.display = 'none';
  const out = document.getElementById('out');
  out.style.display = 'block';
  out.textContent = JSON.stringify(LAST_ROWS.length ? LAST_ROWS : {}, null, 2);
  document.getElementById('viewJson').classList.add('active');
  document.getElementById('viewTable').classList.remove('active');
}

function toCSV(){
  const esc = s => { s = (s===null||s===undefined)?'':String(s);
    return /[",\n]/.test(s) ? '"'+s.replace(/"/g,'""')+'"' : s; };
  const lines = [ LAST_COLS.map(esc).join(',') ];
  for(const row of LAST_ROWS) lines.push(LAST_COLS.map(c => esc(fmtCell(row[c]))).join(','));
  return lines.join('\r\n');
}

document.getElementById('viewTable').onclick = showTable;
document.getElementById('viewJson').onclick  = showJson;
document.getElementById('csvbtn').onclick = ()=>{
  if(!LAST_ROWS.length) return;
  const blob = new Blob([toCSV()], {type:'text/csv'});
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
  a.href = URL.createObjectURL(blob);
  a.download = 'nms_export_' + stamp + '.csv';
  a.click();
  URL.revokeObjectURL(a.href);
};

// Load the endpoint catalog on startup (no auth needed — it's the local spec).
loadEndpoints();
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Quiet, and never log query strings / tokens.
        sys.stderr.write("· %s\n" % (args[0] if args else ""))

    def _send(self, status, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/" or u.path == "/index.html":
            return self._send(200, INDEX_HTML, "text/html; charset=utf-8")
        if u.path == "/_endpoints":
            return self._send(200, ENDPOINTS)
        if u.path == "/_trains":
            if not STATE["token"]:
                return self._send(401, {"error": "not logged in"})
            st, body, ct = nms_request("GET", "/train/project/50", token=STATE["token"])
            return self._send(st, body, ct or "application/json")
        if u.path == "/_proxy":
            if not STATE["token"]:
                return self._send(401, {"error": "not logged in"})
            q = parse_qs(u.query)
            path = q.get("path", [""])[0]
            if not path.startswith("/"):
                return self._send(400, {"error": "path must start with /"})
            # Split any query string already baked into path.
            p = urlparse(path)
            query = {k: v[0] for k, v in parse_qs(p.query).items()}
            st, body, ct = nms_request("GET", p.path, query=query, token=STATE["token"])
            return self._send(st, body, ct or "application/json")
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw or b"{}")
        except Exception:
            payload = {}
        if u.path == "/_login":
            un = payload.get("username", "").strip()
            pw = payload.get("password", "")
            if not un or not pw:
                return self._send(400, {"ok": False, "error": "username+password required"})
            st, body, ct = nms_request("POST", "/user/authenticate",
                                       body={"username": un, "password": pw})
            if st == 200:
                try:
                    tok = json.loads(body).get("token")
                except Exception:
                    tok = None
                if tok:
                    STATE["token"] = tok
                    STATE["username"] = un
                    return self._send(200, {"ok": True, "username": un})
                return self._send(502, {"ok": False, "error": "no token in NMS response"})
            return self._send(st, {"ok": False, "error": "NMS returned HTTP %d" % st})
        return self._send(404, {"error": "not found"})


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", LISTEN_PORT), Handler)
    print("NMS API Console running ->  http://localhost:%d" % LISTEN_PORT)
    print("Target API: %s" % NMS_BASE)
    print("Log in with your own NMS credentials in the browser. Ctrl+C to stop.")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped.")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
